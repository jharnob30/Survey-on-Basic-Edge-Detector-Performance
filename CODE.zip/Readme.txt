Software - Matlab2021

Run "edge detector" named matlab file.

to check edge detection output for the techniques
1.Change dir to how it suits you. 
2.Put your RGB/GRAY image 
3.Comment out Refernece image and evaluating codes.
4.Run

To compare the evaluation results: 
>in the zip file I have provide 5 input image in "test" folder with it's ground truth reference in "reference" folder from "The Berkeley Segmentation Dataset"
>if you have any image with ground truth value put the image in "test"folder and ground truth value in "reference" folder.
1.choose any of the image from test folder as input image by changing in code (im dir).
2.choose it's corresponding ground truth image from reference folder as reference image by changing in code (ref dir).
3.Run the code to evalulate MSE,PSNR,PIQE AND ENTROPY scores.
4.For connected component count put your image in test folder or you can use my given 2 image cc(1),cc(2) and set the name in bottom code where this evaluation happens.
5.Run the code.
6.Evaluate.

Thank you.